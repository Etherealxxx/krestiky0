﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kir
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public enum CellState { Null = 0, Zero = 1, X = 2 }

        CellState cell11 = CellState.Null;
        CellState cell12 = CellState.Null;
        CellState cell13 = CellState.Null;

        CellState cell21 = CellState.Null;
        CellState cell22 = CellState.Null;
        CellState cell23 = CellState.Null;

        CellState cell31 = CellState.Null;
        CellState cell32 = CellState.Null;
        CellState cell33 = CellState.Null;

        Dictionary<int, CellState> Cells = new Dictionary<int, CellState>();
        Dictionary<int, Image> ZeroDict = new Dictionary<int, Image>();
        Dictionary<int, Image> XDict = new Dictionary<int, Image>();
        Dictionary<int, Button> Buttons = new Dictionary<int, Button>();

        public MainWindow()
        {
            InitializeComponent();
            InitField();
            InitPlayer();
            InitDicts();
        }

        private void InitDicts() {
            Cells = new Dictionary<int, CellState> {
                { 0, cell11},
                { 1, cell12},
                { 2, cell13},
                { 3, cell21},
                { 4, cell22},
                { 5, cell23},
                { 6, cell31},
                { 7, cell32},
                { 8, cell33}
            };
            ZeroDict = new Dictionary<int, Image>
            {
                { 0, Zero11},
                { 1, Zero12},
                { 2, Zero13},
                { 3, Zero21},
                { 4, Zero22},
                { 5, Zero23},
                { 6, Zero31},
                { 7, Zero32},
                { 8, Zero33},
            };
            XDict = new Dictionary<int, Image>
            {
                { 0, X11 },
                { 1, X12},
                { 2, X13},
                { 3, X21},
                { 4, X22},
                { 5, X23},
                { 6, X31},
                { 7, X32},
                { 8, X33},
            };
            Buttons = new Dictionary<int, Button>
            {
                { 0, btn11},
                { 1, btn12},
                { 2, btn13},
                { 3, btn21},
                { 4, btn22},
                { 5, btn23},
                { 6, btn31},
                { 7, btn32},
                { 8, btn33},
            };
        }

        private void InitField()
        {
            cell11 = CellState.Null;
            cell12 = CellState.Null;
            cell13 = CellState.Null;

            cell21 = CellState.Null;
            cell22 = CellState.Null;
            cell23 = CellState.Null;

            cell31 = CellState.Null;
            cell32 = CellState.Null;
            cell33 = CellState.Null;
        }

        private void InitPlayer()
        {
            foreach(ComboBoxItem item in CmbBox.Items)
            {
                if (item.Content.ToString() == "крестики" && item.IsSelected == true)
                {
                    PLayerValue = CellState.X;
                    RobotValue = CellState.Zero;
                    return;
                }
                else
                {
                    PLayerValue = CellState.Zero;
                    RobotValue = CellState.X;
                }
            }

        }
        bool Player = true; // определяет чей сейчас ход: игрока или компьютера
        CellState PLayerValue;// определяет какими фигурами ходит игрок
        CellState RobotValue; // определяет какими фигурами ходит компьютер

        private void EnableField()
        {
            btn11.IsEnabled = true;
            btn12.IsEnabled = true;
            btn13.IsEnabled = true;

            btn21.IsEnabled = true;
            btn22.IsEnabled = true;
            btn23.IsEnabled = true;

            btn31.IsEnabled = true;
            btn32.IsEnabled = true;
            btn33.IsEnabled = true;
            for (int i=0; i < 9; i++)
            {
                Cells[i] = CellState.Null; 
            }
        }
        private void DisableField()
        {
            btn11.IsEnabled = false;
            btn12.IsEnabled = false;
            btn13.IsEnabled = false;

            btn21.IsEnabled = false;
            btn22.IsEnabled = false;
            btn23.IsEnabled = false;

            btn31.IsEnabled = false;
            btn32.IsEnabled = false;
            btn33.IsEnabled = false;
        }

        bool isGameStop = false;

        private void btn11_Click(object sender, RoutedEventArgs e)
        {
            btn11.IsEnabled = false;
            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero11.Visibility = Visibility.Visible;
                    Cells[0] = CellState.Zero;
                    break;
                case CellState.X:
                    X11.Visibility = Visibility.Visible;
                    Cells[0] = CellState.X;
                    break; 
            }
            IsGameEnd();
            if(!isGameStop)
                RobotStep();
        }

        private void btn12_Click(object sender, RoutedEventArgs e)
        {
            btn12.IsEnabled = false;

            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero12.Visibility = Visibility.Visible;
                    Cells[1] = CellState.Zero;
                    break;
                case CellState.X:
                    X12.Visibility = Visibility.Visible;
                    Cells[1] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();
        }

        private void btn13_Click(object sender, RoutedEventArgs e)
        {
            btn13.IsEnabled = false;

            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero13.Visibility = Visibility.Visible;
                    Cells[2] = CellState.Zero;
                    break;
                case CellState.X:
                    X13.Visibility = Visibility.Visible;
                    Cells[2] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();

        }

        private void btn21_Click(object sender, RoutedEventArgs e)
        {
            btn21.IsEnabled = false;

            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero21.Visibility = Visibility.Visible;
                    Cells[3] = CellState.Zero;
                    break;
                case CellState.X:
                    X21.Visibility = Visibility.Visible;
                    Cells[3] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();
        }

        private void btn22_Click(object sender, RoutedEventArgs e)
        {
            btn22.IsEnabled = false;
            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero22.Visibility = Visibility.Visible;
                    Cells[4] = CellState.Zero;
                    break;
                case CellState.X:
                    X22.Visibility = Visibility.Visible;
                    Cells[4] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();
        }

        private void btn23_Click(object sender, RoutedEventArgs e)
        {
            btn23.IsEnabled = false;

            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero23.Visibility = Visibility.Visible;
                    Cells[5] = CellState.Zero;
                    break;
                case CellState.X:
                    X23.Visibility = Visibility.Visible;
                    Cells[5] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();
        }

        private void btn31_Click(object sender, RoutedEventArgs e)
        {
            btn31.IsEnabled = false;

            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero31.Visibility = Visibility.Visible;
                    Cells[6] = CellState.Zero;
                    break;
                case CellState.X:
                    X31.Visibility = Visibility.Visible;
                    Cells[6] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();
        }

        private void btn32_Click(object sender, RoutedEventArgs e)
        {
            btn32.IsEnabled = false;
            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero32.Visibility = Visibility.Visible;
                    Cells[7] = CellState.Zero;
                    break;
                case CellState.X:
                    X32.Visibility = Visibility.Visible;
                    Cells[7] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();
        }

        private void btn33_Click(object sender, RoutedEventArgs e)
        {
            btn33.IsEnabled = false;

            switch (PLayerValue)
            {
                case CellState.Zero:
                    Zero33.Visibility = Visibility.Visible;
                    Cells[8] = CellState.Zero;
                    break;
                case CellState.X:
                    X33.Visibility = Visibility.Visible;
                    Cells[8] = CellState.X;
                    break;
            }
            IsGameEnd();
            if (!isGameStop)
                RobotStep();
        }

        private void SetVisibilityImages(Visibility visibility)
        {
            for(int i=0; i < 9; i++)
            {
                XDict[i].Visibility = visibility;
                ZeroDict[i].Visibility = visibility;
            }
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            InitPlayer();
            StartBtn.IsEnabled = false;
            RestartBtn.IsEnabled = true;
            EnableField();
            CmbBox.IsEnabled = false;
        }

        private void ReatartBtn_Click(object sender, RoutedEventArgs e)
        {
            InitField();
            EnableField();
            SetVisibilityImages(Visibility.Hidden);
            isGameStop = false;
            Player = !Player;
            if (!Player)
                RobotStep();
        }

        private void RobotStep()
        {
            Random random = new Random();
            while (true)
            {
                List<int> vals = new List<int>();
                for (int i =0; i < 9; i++)
                {
                    if (Cells[i] == CellState.Null)
                        vals.Add(i);
                }
                int cell = 0;
                if (vals.Count > 1)
                {
                    cell = vals[random.Next(0, vals.Count - 1)];
                }
                else if (vals.Count == 0)
                {
                    MessageBox.Show("Ничья");
                    return;
                }
                else
                    cell = vals[0];

                if (SetCellByRobot(cell))
                {
                    IsGameEnd();
                    return;
                }
            }
        }

        private bool SetCellByRobot(int number)
        {
            if (Cells[number] == CellState.Null)
            {
                Cells[number] = RobotValue;
                switch (RobotValue)
                {
                    case CellState.Zero:
                        ZeroDict[number].Visibility = Visibility.Visible;
                        Buttons[number].IsEnabled = false;
                        return true;
                    case CellState.X:
                        XDict[number].Visibility = Visibility.Visible;
                        Buttons[number].IsEnabled = false;
                        return true;
                }
            }
            return false;
        }

        #region CheckResult

        private void IsGameEnd()
        {
            int stepCount=0;
            for (int i=0; i<9; i++)
            {
                if (Cells[i] != CellState.Null)
                    stepCount++;
            }
            if (stepCount < 5) return;
            CellState result = CheckResult();
            if (result != CellState.Null)
            {
                switch (result)
                {
                    case CellState.Zero:
                        MessageBox.Show("Победили нолики");
                        break;
                    case CellState.X:
                        MessageBox.Show("Победили крестики");
                        break;
                }
                isGameStop = true;
                DisableField();
            }
        }

        private CellState CheckResult()
        {
            CellState result = CellState.Null;
            result = CheckHorizontal();
            if (result != CellState.Null)
                return result;
            result = CheckVertical();
            if (result != CellState.Null)
                return result;

            if (Cells[0] == Cells[4] && Cells[4] == Cells[8])
            {
                result = Cells[0];
                return result;
            }

            if (Cells[2] == Cells[4] && Cells[4] == Cells[6])
            {
                result = Cells[2];
                return result;
            }
            return result;
        }

        private CellState CheckVertical()
        {
            CellState result = CellState.Null;
            CellState[] points = new CellState[3] { CellState.Null, CellState.Null, CellState.Null };
            for (int i = 0; i <= 6; i+=3)
            {
                for (int j = 0; j <= 2; j++)
                {
                    points[j] = Cells[i + j];
                    bool isVictory = CheckPoints(points);
                    if (points[1] != CellState.Null && !isVictory)
                        continue;
                    if (isVictory)
                    {
                        result = points[0];
                        return result;
                    }
                }
            }
            return result;
        }
        private CellState CheckHorizontal()
        {
            CellState result = CellState.Null;
            CellState[] points = new CellState[3] { CellState.Null, CellState.Null, CellState.Null };
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j <= 6; j += 3)
                {
                    points[j/3] = Cells[i + j];
                    bool isVictory = CheckPoints(points);
                    if (points[1] != CellState.Null && !isVictory)
                        continue;
                    if (isVictory)
                    {
                        result = points[0];
                        return result;
                    }
                }
            }
            return result;
        }

        private bool CheckPoints(CellState[] points)
        {
            if (points[0] == CellState.Null || points[1] == CellState.Null)
                return false;

            else if (points[0] == points[1] && points[0] == points[2])
                return true;
            
            else 
                return false;
        }

        #endregion

    }
}
